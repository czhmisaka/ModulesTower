/*
 * @Date: 2022-10-26 11:24:08
 * @LastEditors: CZH
 * @LastEditTime: 2022-12-15 14:22:01
 * @FilePath: /configforpagedemo/src/modules/userManager/output.ts
 */
export const moduleInfo = {
  name: "userManager",
  title: "管理中心组件包2",
  icon: "EL_Setting",
  info: "部门 人员 角色 权限管理",
  author: "czh & ljh",
};

export const output = {
  moduleApi: {},
  CardApiInjectComponent: {},
  routerChecker: {},
};

// 模组打包配置
export const modulePackConfig = {};
