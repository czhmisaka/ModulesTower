var s=(e=>(e.message="message",e.element="element",e.icon="icon",e.image="image",e.sleep="sleep",e))(s||{});export{s as i};
