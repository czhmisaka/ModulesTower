const c=(e,t)=>{},o={moduleApi:{},component:{}};export{c as checkLicense,o as default};
