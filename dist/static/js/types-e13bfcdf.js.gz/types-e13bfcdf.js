var r=(u=>(u.Function="Function",u.RouterPush="RouterPush",u.MenuCellList="MenuCellList",u))(r||{});export{r as menuCellActionTemplate};
