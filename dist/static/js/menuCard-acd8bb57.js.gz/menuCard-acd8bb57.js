import{A as e,a2 as t}from"./index-51f9d840.js";const n=e({props:["detail","template"],setup(){return{}}});function r(o,s,a,p,c,u){return null}const d=t(n,[["render",r]]);export{d as default};
