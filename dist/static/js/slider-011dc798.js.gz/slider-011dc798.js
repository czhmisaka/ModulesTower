const e=async()=>[];export{e as sliderMqttDevice};
