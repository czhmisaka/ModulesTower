const t="/lcdp_oms/static/png/noData-0cfb7663.png";export{t as default};
