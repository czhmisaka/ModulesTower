var g=(e=>(e.elIcon="elicon",e.svg="svg",e.image="image",e))(g||{});export{g as IconType};
