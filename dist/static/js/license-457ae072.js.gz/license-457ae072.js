import{A as e,a2 as n}from"./index-51f9d840.js";const t=e({components:{},setup(){return{}}});function o(s,r,c,p,a,_){return null}const u=n(t,[["render",o]]);export{u as default};
