import{bb as a}from"./index-51f9d840.js";const o={};let t={};Object.keys(o).map(e=>{a(e,o)&&(t[String(e).toUpperCase()]=o[e])});const g={...t};export{g as PageConfig};
